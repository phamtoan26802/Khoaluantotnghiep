package com.example.leskin.repository;

import com.example.leskin.repository.entity.Service;
import org.springframework.stereotype.Repository;

@Repository
public interface ServiceRepository extends BaseRepository<Service> {
}
