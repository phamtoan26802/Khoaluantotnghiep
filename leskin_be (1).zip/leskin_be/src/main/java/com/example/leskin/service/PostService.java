package com.example.leskin.service;

import com.example.leskin.repository.entity.Post;


public interface PostService extends BaseService<Post>{
}
