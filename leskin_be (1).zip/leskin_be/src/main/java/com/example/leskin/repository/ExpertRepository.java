package com.example.leskin.repository;

import com.example.leskin.repository.entity.Expert;
import org.springframework.stereotype.Repository;

@Repository
public interface ExpertRepository extends BaseRepository<Expert>{
}
