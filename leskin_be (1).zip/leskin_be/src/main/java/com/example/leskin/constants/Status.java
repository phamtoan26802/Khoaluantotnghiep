package com.example.leskin.constants;

public class Status {
    public static final Integer ACTIVE = 1;
    public static final Integer INACTIVE = 0;
    public static final Integer DELETED = -1;
}
