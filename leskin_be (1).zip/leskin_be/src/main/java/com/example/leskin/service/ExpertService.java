package com.example.leskin.service;

import com.example.leskin.repository.entity.Expert;

public interface ExpertService extends BaseService<Expert>{
}
