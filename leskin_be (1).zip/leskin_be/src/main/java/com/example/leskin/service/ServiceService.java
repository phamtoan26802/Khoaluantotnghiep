package com.example.leskin.service;

import com.example.leskin.repository.entity.Service;

public interface ServiceService extends BaseService<Service>{
}
