package com.example.leskin.uitl;

import lombok.Data;
import org.springframework.stereotype.Component;

@Component
@Data
public class ContextUtil {
    private String userName;
}
