package com.example.leskin.repository;

import com.example.leskin.repository.entity.Post;
import org.springframework.stereotype.Repository;

@Repository
public interface PostRepository extends BaseRepository<Post>{
}
